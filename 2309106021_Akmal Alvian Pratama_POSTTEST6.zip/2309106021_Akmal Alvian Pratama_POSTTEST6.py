# Inisialisasi data kue lebaran dalam bentuk nested dictionary
kue_lebaran = {}

# Fungsi untuk menambahkan kue baru
def create_kue(user):
    if user["peran"] == "admin":
        nama_kue = input("Masukkan nama kue: ")
        while True:
            harga_kue = input("Masukkan harga kue: ")
            if harga_kue.isdigit():  # Memeriksa apakah input harga adalah angka
                kue_lebaran[nama_kue] = int(harga_kue)
                print("Kue '{}' telah ditambahkan.".format(nama_kue))
                break
            else:
                print("Harga kue harus berupa angka. Silakan coba lagi.")
    else:
        print("Anda tidak memiliki izin untuk menambahkan kue.")


# Fungsi untuk melihat daftar kue
def read_kue():
    print("Daftar Kue Lebaran:")
    for nama_kue, harga in kue_lebaran.items():
        print("Nama: {}, Harga: {}".format(nama_kue, harga))

# Fungsi untuk memperbarui data kue
def update_kue(user):
    if user["peran"] == "admin":
        read_kue()
        kue_dipilih = input("Masukkan nama kue yang ingin diperbarui: ")
        if kue_dipilih in kue_lebaran:
            new_nama = input("Masukkan nama baru untuk kue (biarkan kosong jika tidak ingin mengubah): ")
            new_harga = input("Masukkan harga baru untuk kue: ")
            while True:
                if new_harga.isdigit():  # Memeriksa apakah input harga adalah angka
                    kue_lebaran[kue_dipilih] = int(new_harga)
                    if new_nama:  # Periksa jika pengguna ingin mengubah nama kue
                        kue_lebaran[new_nama] = kue_lebaran.pop(kue_dipilih)
                    print("Kue telah diperbarui.")
                    break
                else:
                    print("Harga kue harus berupa angka. Silakan coba lagi.")
        else:
            print("Nama kue tidak ditemukan.")
    else:
        print("Anda tidak memiliki izin untuk memperbarui kue.")



# Fungsi untuk menghapus kue
def delete_kue(user):
    if user["peran"] == "admin":
        read_kue()
        kue_dipilih = input("Masukkan nama kue yang ingin dihapus: ")
        if kue_dipilih in kue_lebaran:
            del kue_lebaran[kue_dipilih]
            print("Kue '{}' telah dihapus.".format(kue_dipilih))
        else:
            print("Nama kue tidak ditemukan.")
    else:
        print("Anda tidak memiliki izin untuk menghapus kue.")


# Fungsi untuk registrasi pengguna baru
def register():
    username = input("Masukkan nama pengguna: ")
    password = input("Masukkan kata sandi: ")
    peran = input("Masukkan peran (admin/user): ")  # Admin atau User
    users[username] = {"password": password, "peran": peran}


# Fungsi untuk login
def login():
    username = input("Nama Pengguna: ")
    password = input("Kata Sandi: ")
    if username in users and users[username]["password"] == password:
        return users[username]
    return None


# Fungsi utama setelah login
def menu_utama(user):
    while True:
        if user["peran"] == "admin":
            print("\nProgram CRUD Kue Lebaran")
            print("1. Lihat Kue")
            print("2. Tambah Kue")
            print("3. Perbarui Kue")
            print("4. Hapus Kue")
            print("5. Keluar")
            choice = input("Pilih tindakan (1/2/3/4/5): ")
        else:
            print("\nProgram Belanja Kue Lebaran")
            print("1. Lihat Kue")
            print("2. Kembali ke Menu Utama")
            choice = input("Pilih tindakan (1/2): ")

        if choice == "1":
            read_kue()
        elif user["peran"] == "admin" and choice == "2":
            create_kue(user)
        elif user["peran"] == "admin" and choice == "3":
            update_kue(user)
        elif user["peran"] == "admin" and choice == "4":
            delete_kue(user)
        elif choice == "5":
            print("Terima kasih! Sampai jumpa.")
            break
        elif user["peran"] != "admin" and choice == "2":
            return  # Kembali ke menu utama
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")


# Inisialisasi data pengguna
users = {}


# Fungsi utama
def main():
    while True:
        print("Selamat datang di Program CRUD Kue Lebaran")
        print("1. Login")
        print("2. Registrasi")
        print("3. Keluar")
        choice = input("Pilih tindakan (1/2/3): ")

        if choice == "1":
            user = login()
            if user:
                print("Selamat datang,", user["peran"])
                menu_utama(user)
            else:
                print("Login gagal. Nama pengguna atau kata sandi tidak valid.")
        elif choice == "2":
            register()
        elif choice == "3":
            print("Terima kasih! Sampai jumpa.")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    main()
