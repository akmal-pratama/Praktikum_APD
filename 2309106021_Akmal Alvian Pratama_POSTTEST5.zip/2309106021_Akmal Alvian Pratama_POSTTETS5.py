print("Nama : Akmal Alvian Pratama")
print("Nim : 2309106021")
print("Tema : Kue Lebaran")
print()

# Inisialisasi data kue lebaran dalam bentuk nested list
kue_lebaran = []

# Fungsi untuk menambahkan kue baru
def create_kue(user):
    if user[2] == "admin":
        nama_kue = input("Masukkan nama kue: ")
        while True:
            harga_kue = input("Masukkan harga kue: ")
            if harga_kue.isdigit():  # Memeriksa apakah input harga adalah angka
                kue_lebaran.append([nama_kue, harga_kue])
                print("Kue '{}' telah ditambahkan.".format(nama_kue))
                break
            else:
                print("Harga kue harus berupa angka. Silakan coba lagi.")
    else:
        print("Anda tidak memiliki izin untuk menambahkan kue.")

# Fungsi untuk melihat daftar kue
def read_kue():
    print("======================")
    print("Daftar Kue Lebaran:")
    print("======================")
    for index, kue in enumerate(kue_lebaran):
        print("------------------------------------")
        print("{}. Nama: {}, Harga: {}".format(index + 1, kue[0], kue[1]))
        print("------------------------------------")

# Fungsi untuk memperbarui data kue
def update_kue(user):
    if user[2] == "admin":
        read_kue()
        try:
            index = int(input("Pilih nomor kue yang ingin diperbarui: ")) - 1
            if 0 <= index < len(kue_lebaran):
                new_nama = input("Masukkan nama baru untuk kue: ")
                while True:
                    new_harga = input("Masukkan harga baru untuk kue: ")
                    if new_harga.isdigit():  # Memeriksa apakah input harga adalah angka
                        kue_lebaran[index] = [new_nama, new_harga]
                        print("Kue telah diperbarui.")
                        break
                    else:
                        print("Harga kue harus berupa angka. Silakan coba lagi.")
            else:
                print("Nomor kue tidak valid.")
        except ValueError:
            print("Masukan tidak valid. Harap masukkan nomor kue yang benar.")
    else:
        print("Anda tidak memiliki izin untuk memperbarui kue.")

# Fungsi untuk menghapus kue
def delete_kue(user):
    if user[2] == "admin":
        read_kue()
        try:
            index = int(input("Pilih nomor kue yang ingin dihapus: ")) - 1
            if 0 <= index < len(kue_lebaran):
                deleted_kue = kue_lebaran.pop(index)
                print("Kue '{}' telah dihapus.".format(deleted_kue[0]))
            else:
                print("Nomor kue tidak valid.")
        except ValueError:
            print("Masukan tidak valid. Harap masukkan nomor kue yang benar.")
    else:
        print("Anda tidak memiliki izin untuk menghapus kue.")

# Fungsi untuk registrasi pengguna baru
def register():
    username = input("Masukkan nama pengguna: ")
    password = input("Masukkan kata sandi: ")
    peran = input("Masukkan peran (admin/user): ")  # Admin atau User
    users.append([username, password, peran])

# Fungsi untuk login
def login():
    username = input("Nama Pengguna: ")
    password = input("Kata Sandi: ")
    for user in users:
        if user[0] == username and user[1] == password:
            return user
    return None


# Fungsi utama setelah login
def menu_utama(user):
    while True:
        if user[2] == "admin":
            print("1. Lihat Kue (Read)")
            print("2. Tambah Kue (Creat)")
            print("3. Perbarui Kue (Update)")
            print("4. Hapus Kue (Delate)")
            print("5. Keluar")
            choice = input("Pilih tindakan (1/2/3/4/5): ")
        else:
            print("\nProgram Belanja Kue Lebaran")
            print("1. Lihat Kue")
            print("2. Kembali ke Menu Utama")
            choice = input("Pilih tindakan (1/2): ")

        if choice == "1":
            read_kue()
        elif user[2] == "admin" and choice == "2":
            create_kue(user)
        elif user[2] == "admin" and choice == "3":
            update_kue(user)
        elif user[2] == "admin" and choice == "4":
            delete_kue(user)
        elif choice == "5":
            print("Terima kasih! Sampai jumpa.")
            break
        elif user[2] != "admin" and choice == "2":
            return  # Kembali ke menu utama
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")


# Inisialisasi data pengguna
users = []

# Fungsi utama
def main():
    while True:
        print("=================================================")
        print("Selamat datang di Program CRUD Kue Lebaran :))  |")
        print("Silahkan Melakukan Registrasi terlebih dahulu   |")
        print("=================================================")
        print("1. Login")
        print("2. Registrasi")
        print("3. Keluar")
        choice = input("Pilih tindakan (1/2/3): ")

        if choice == "1":
            user = login()
            if user:
                print("*****************************")
                print("Selamat datang,", user[0])
                print("*****************************")
                menu_utama(user)
            else:
                print("Login gagal. Nama pengguna atau kata sandi tidak valid.")
        elif choice == "2":
            register()
        elif choice == "3":
            print("Terima kasih! Sampai jumpa. :)")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    main()