nama_user = "Akmal"
password_user = "32"
login_attempts = 0
user_logged_in = False  # New variable to check if the user logged in successfully

while True:
    # Minta user untuk memasukkan nama dan password
    nama_input = input("Masukkan nama Anda: ")
    password_input = input("Masukkan password Anda: ")
    # Periksa apakah nama dan password yang dimasukkan benar
    if nama_input == nama_user and password_input == password_user:
        print("Login berhasil!")
        user_logged_in = True
        break
    else:
        print("Login gagal!")
        login_attempts += 1
    # Jika login gagal 3x, hentikan program
    if login_attempts == 3:
        print("Anda telah gagal login 3x. Program akan dihentikan.")
        break

if user_logged_in:  # Only display the menu if the user logged in successfully
    while True:
        # Tampilkan menu
        print("Pilih opsi:")
        print("1.  BMI")
        print("2. Keluar")
        # Minta user untuk memilih opsi
        pilihan = input("Masukkan pilihan Anda: ")
        # Lakukan sesuatu berdasarkan pilihan user
        if pilihan == "1":
            # Input berat badan dalam kg
            berat_badan_kg = float(input("Masukkan berat badan (kg): "))
            tinggi_badan_cm = float(input("Masukkan tinggi badan (centimeter): "))
            # Menghitung BMI
            bmi = berat_badan_kg / ((tinggi_badan_cm/100) * (tinggi_badan_cm/100))
            # Menentukan kategori BMI
            if bmi < 18.5:
                 kategori = "Underweight (Kurang dari berat)"
            elif bmi < 24.9:
                kategori = "Normal (Berat badan normal)"
            elif bmi < 29.9:
                kategori = "Overweight (Berat badan berlebih)"
            else:
                kategori = "Obesitas"
            # Menampilkan hasil
            print("BMI Anda:", bmi)
            print("Kategori BMI Anda:", kategori)
            break
        elif pilihan == "2":
            # Keluar dari program
            break
        else:
            # Pilihan tidak valid
            print("Pilihan tidak valid!")