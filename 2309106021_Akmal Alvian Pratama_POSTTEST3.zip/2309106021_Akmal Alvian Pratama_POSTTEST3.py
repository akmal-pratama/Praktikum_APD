# Input berat badan dalam kg
berat_badan_kg = float(input("Masukkan berat badan (kg): "))

# Input tinggi badan dalam centimeter
tinggi_badan_cm = float(input("Masukkan tinggi badan (centimeter): "))

# Menghitung BMI
bmi = berat_badan_kg / ((tinggi_badan_cm/100) * (tinggi_badan_cm/100))

# Menentukan kategori BMI
if bmi < 18.5:
    kategori = "Underweight (Kurang dari berat)"
elif bmi < 24.9:
    kategori = "Normal (Berat badan normal)"
elif bmi < 29.9:
    kategori = "Overweight (Berat badan berlebih)"
else:
    kategori = "Obesitas"

# Menampilkan hasil
print("BMI Anda:", bmi)
print("Kategori BMI Anda:", kategori)
